#- descargo los datos del trabajo y guardo una copia en datos/
#- solo hay que ejecutarlo una vez: el trabajo (trabajo.qmd) lee la copia, no los datos de Eurostat
#- así la web se genera más rápido y no depende de que la web de Eurostat funcione

library(tidyverse)
library(eurostat)   #- pak::pak("eurostat")

#- edad media a la que los jóvenes se van de casa de sus padres, por sexo (yth_demo_030)
#- me quedo con los países (código de 2 letras) y la UE-27, y añado el nombre del país
get_eurostat("yth_demo_030", time_format = "num") |>
  filter(str_length(geo) == 2 | geo == "EU27_2020") |>
  mutate(pais = label_eurostat(geo, dic = "geo")) |>
  select(geo, pais, sexo = sex, year = TIME_PERIOD, edad = values) |>
  write_csv("./datos/eurostat_emancipacion.csv")

#- % de jóvenes de 16 a 29 años que gastan más del 40 % de su renta en vivienda (ilc_lvho07a)
#- (por sexo: T, M y F; total de los niveles de renta)
get_eurostat("ilc_lvho07a", time_format = "num") |>
  filter(age == "Y16-29", rskpovth == "TOTAL") |>
  filter(str_length(geo) == 2 | geo == "EU27_2020") |>
  select(geo, sexo = sex, year = TIME_PERIOD, sobrecarga = values) |>
  write_csv("./datos/eurostat_sobrecarga_vivienda.csv")

#- nivel de precios de la vivienda (índice de nivel de precios, UE-27 = 100) (prc_ppp_ind)
#- es "vivienda, agua, electricidad, gas y otros combustibles": incluye los suministros, no solo el alquiler
get_eurostat("prc_ppp_ind", time_format = "num") |>
  filter(na_item == "PLI_EU27_2020", ppp_cat == "A0104") |>
  filter(str_length(geo) == 2 | geo == "EU27_2020") |>
  select(geo, year = TIME_PERIOD, precios = values) |>
  write_csv("./datos/eurostat_precios_vivienda.csv")
