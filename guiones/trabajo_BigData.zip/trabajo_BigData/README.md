
## Trabajo en equipo para la asignatura "Big Data"

<!-- El párrafo de abajo has de dejarlo tal cual. NO HAS DE CAMBIAR NADA!!-->

Repo utilizado para elaborar el trabajo para la asignatura "Programación y manejo de datos en la era del Big Data" de la Universitat de València durante el curso 2026-2027.
La página web de la asignatura puede verse aquí: <https://perezp44.github.io/intro-ds-26-27-web/>

<!-- CAMBIALO !!! En la línea de abajo HAS de SUSTITUIR "tu-usuario" por tu usuario de Github
(y si es el trabajo individual, trabajo_BigData_equipo por trabajo_BigData) -->
La versión final del trabajo puede visualizarse en: <https://tu-usuario.github.io/trabajo_BigData_equipo/>

<!-- Abajo podéis escribir lo que queráis, igual un resumen del trabajo, o ..., o ...
pero al menos tenéis que poner el título del trabajo y vuestros nombres -->

<!-- CAMBIALO !!! -->
Los autores del trabajo somos Robert Allen Zimmerman (roalzixxxxx8888@alumni.uv.es), Ruben Blades (xxxx@alumni.uv.es) y .....

El título del trabajo es .....  

En el trabajo hacemos .... blah-blah ...
